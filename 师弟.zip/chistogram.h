#ifndef CHISTOGRAM_H
#define CHISTOGRAM_H

#include <opencv2/core/core.hpp>
#include <vector>

using namespace cv;

void showHistogram(Mat im,string str);

#endif