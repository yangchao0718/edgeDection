#include <iostream>
#include <fstream>
#include <string>
#include <opencv2/highgui/highgui.hpp>  
#include <opencv2/imgproc/imgproc.hpp>  
#include "highgui.h"  
#include <cv.h>  
#include <cvaux.h>

using namespace std;
using namespace cv;

//template< class T>

void outXls(string str, Mat im, string dataType);