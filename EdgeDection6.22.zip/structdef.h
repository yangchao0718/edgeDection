//proecss global struct variable
#ifndef STRUCTDEF_H
#define STRUCTDEF_H
struct MyStruct
{
	int m_num;
	int m_index;
};
#endif